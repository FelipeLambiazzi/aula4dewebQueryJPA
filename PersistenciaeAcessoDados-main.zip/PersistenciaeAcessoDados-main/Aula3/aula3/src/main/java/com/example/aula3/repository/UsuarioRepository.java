package com.example.aula3.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.example.aula3.entity.Usuario;

import org.hibernate.sql.Delete;
import org.hibernate.sql.Update;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class UsuarioRepository {
        private static String DELETE =
        "DELETE FROM USUARIO WHERE ID = ?";
        private static String UPDATE =
        "UPDATE usuario set nome=?,email=?,senha=? where id = ? ";
        private static String AUTENTICAR = 
        "Select * from usuario where email =? and senha =?";


    @Autowired
    private EntityManager entityManager;

    // marcar o transactional pois vai dar pau se nao por e fizer o insert desta forma
    @Transactional
    public Usuario inserir(Usuario usuario){
        entityManager.persist(usuario);
        return usuario;
    }

    @Transactional
    public Usuario atualizar(Usuario usuario){
        entityManager.merge(usuario);
        return usuario;
    }

    @Transactional
    public void excluir(Usuario usuario){
        entityManager.remove(usuario);
    }

    @Transactional
    public void excluir (int id){
        excluir(entityManager.find(Usuario.class, id));
    }

    @Transactional(readOnly = true)
    public List<Usuario> obterTodos(){
        return entityManager.createQuery("From Usuario",Usuario.class)
                                                        .getResultList();
    } 
    @Transactional
    public List<Usuario> obterPorNome(String nome){
        String jpql = "select u from Usuario u where u.nome like:nome";
        TypedQuery<Usuario> query = 
            entityManager.createQuery(jpql,Usuario.class);
            query.setParameter("nome", "%" +nome+ "%");
            return query.getResultList();
        
    }

    


}
